<template>
  <q-page>
    <slot></slot>
  </q-page>
</template>
