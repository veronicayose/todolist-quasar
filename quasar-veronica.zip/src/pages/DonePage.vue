<template>
  <base-page class="column items-center">
    <!-- Header -->
    <h3 class="text-bold q-my-xl">Done List Page</h3>
    <q-btn color="primary" label="Back" @click="$router.push('/')" />
    <!-- List of Cards -->
    <div v-for="todo in todoList" :key="todo.id" style="width: 95%">
      <base-card
        v-if="todo.isDone"
        class="row justify-between q-pa-md q-my-sm"
        style="width: 100%"
      >
        <q-checkbox class="col-1" v-model="todo.isDone"></q-checkbox>
        <div class="col-8">
          <h5 class="q-ma-xs text-bold">{{ todo.title }}</h5>
          <h7 class="q-mx-xs">{{ todo.description }}</h7>
        </div>
        <div>
          <h6 class="q-ma-xs text-weight-thin">Deadline</h6>
          <h7 class="q-mx-xs">{{ todo.deadline }}</h7>
        </div>
        <div class="row justify-center">
          <q-btn
            flat
            color="primary"
            icon="edit"
            @click="$router.push('/edit')"
          />
          <q-btn flat color="primary" icon="delete" @click="confirm = true" />
        </div>
      </base-card>
    </div>
    <q-dialog v-model="confirm">
      <q-card>
        <q-card-section>
          <h5 class="text-bold q-ma-md">Delete List</h5>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="Cancel" color="primary" v-close-popup />
          <q-btn flat label="Delete" color="primary" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </base-page>
</template>

<script>
import { defineComponent, ref } from 'vue';
import BasePage from '../components/BasePage.vue';
import BaseCard from '../components/BaseCard.vue';
import todoList from '../todoList.ts';

export default defineComponent({
  setup() {
    return {
      todoList,
      confirm: ref(false),
    };
  },
  components: {
    BasePage,
    BaseCard,
  },
});
</script>
