<template>
  <q-card>
    <slot></slot>
  </q-card>
</template>
