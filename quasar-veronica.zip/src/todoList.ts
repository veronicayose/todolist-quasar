const todoList = [
  {
    id: 1,
    title: 'Dicoding',
    description: 'Simulasi Ujian Associate Cloud Engineer',
    deadline: '10/07/2023',
    isDone: true,
  },
  {
    id: 2,
    title: 'Dicoding',
    description: 'Pemrograman Web Dasar',
    deadline: '02/03/2023',
    isDone: false,
  },
  {
    id: 3,
    title: 'Dicoding',
    description: 'Pemrograman Web Dasar',
    deadline: '20/03/2023',
    isDone: true,
  },
  {
    id: 4,
    title: 'Dicoding',
    description: 'Pemrograman Web Dasar',
    deadline: '20/03/2023',
    isDone: true,
  },
];

export default todoList;
