<template>
  <base-page class="column items-center">
    <!-- Header -->
    <h3 class="text-bold q-my-xl">Add Page</h3>
    <q-btn color="primary" label="Back" @click="$router.push('/')" />
    <q-card style="width: 80%" class="q-pa-md q-my-md">
      <q-form>
        <q-input square outlined v-model="title" label="Title"></q-input>
        <q-input
          square
          outlined
          v-model="description"
          class="q-mt-md"
          label="Description"
        ></q-input>
        <q-input
          square
          outlined
          v-model="deadline"
          class="q-mt-md"
          type="date"
          label="Deadline"
        ></q-input>
        <q-btn color="primary" class="q-mt-md" label="Submit" />
      </q-form>
    </q-card>
  </base-page>
</template>

<script>
import BasePage from 'src/components/BasePage.vue';
import { ref } from 'vue';
// import todoList from '../todoList.ts';

export default {
  components: { BasePage },
  setup() {
    return {
      title: ref(''),
      description: ref(''),
      deadline: ref(''),
    };
  },
};
</script>
